import React from 'react'
import '../styles/App.css'

const App = () => {
  return (
    <div className='app'>
      <h1>Twitcoders</h1>
    </div>
  )
}

export default App
